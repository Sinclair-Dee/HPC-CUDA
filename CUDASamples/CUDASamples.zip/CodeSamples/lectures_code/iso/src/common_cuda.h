#ifndef COMMON_CUDA_H
#define COMMON_CUDA_H

#ifdef __cplusplus
extern "C" {
#endif

extern int getNumCUDADevices();

#ifdef __cplusplus
}
#endif

#endif
