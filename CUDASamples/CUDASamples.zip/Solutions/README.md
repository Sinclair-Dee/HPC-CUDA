Professional CUDA C Programming
===============================

Included here are solution text and code for each chapter's exercises.

The text solutions for every chapter is included in ExerciseSolutions.pdf.

Each chapter also has its own code folder that includes sample .c and .cu
code solutions for any exercises which require them. The per-chapter code
folders each also include a Makefile that can be used to build the solutions
included.

The common/ directory contains common.h, which includes code that is common to
multiple chapters.
